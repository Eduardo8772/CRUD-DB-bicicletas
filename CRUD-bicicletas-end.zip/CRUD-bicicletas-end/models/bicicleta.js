
// Obtiene la conexión con la base de datos
const knex = require('../database/connection');

// Almacena en la base de datos el producto
exports.create = (bici) => {
    return knex('bicicletas')
      .insert({
        color: bici.color,
        modelo: bici.modelo,
        lat: bici.lat,
        lon: bici.lon
      });
  }

// Obtiene todos los productos en la base
exports.all = () => {
    // Realiza la consulta dentro de knex
    return knex
      .select('*')
      .from('bicicletas');
  }

  exports.removeById = (aBiciId) => {
      idP = parseInt(aBiciId)
      return knex('bicicletas').where({id: idP}).first();
  }

  exports.findById = (aBiciId) => {
      idP = parseInt(aBiciId)
      let aBici = knex
      .select('*')
      .from('bicicletas')
      .where({id: idP})
      .first();
      if(aBici){
          console.log(aBici.color)
          return aBici
      }
      else {
          throw new Error('No hay bicicleta con ese id')
      }
  }

  exports.update = (id, bici) =>{
      return knex('bicicletas')
      .update(bici)
      .update('update_at', knex.fn.now())
      .where('id', parseInt(id));
  }
