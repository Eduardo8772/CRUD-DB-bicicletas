/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> } 
 */
exports.seed = async function(knex) {
  // Deletes ALL existing entries
  return knex('table_name').del()
    .then(function () {
      return knex('bicicletas').insert([
        {color: 'Morado', modelo: 'Ruta', lat: 19.45678, lon:-99.456789},
        {color: 'Rojo', modelo: 'Cross', lat: 19.45678, lon:-99.098765},
        {color: 'Rosa', modelo: 'BMX', lat: 19.65432, lon:-99.23654}
      ]);
    })
};
